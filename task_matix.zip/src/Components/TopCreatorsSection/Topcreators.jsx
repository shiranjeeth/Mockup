import React from 'react'
import '../TopCreatorsSection/topcreators.css';
import bannerimage from '../../assets/bannerheade.png'
const Topcreators = () => {
  return (
    <div className='topcreators-main-above'>

  
    <div className='topcreators-main'>
        <h2>Top Creaters</h2>

        <div className='topcreators-imgs-section'>
     
      <div className="topcreators-img">
          <img src={bannerimage} className="img-responsive" alt="Logo" />
          <div className="topcreators-rightcontent">
            <h3>lenin quies</h3>
            <p> 178 items</p>
          </div>
        </div>
      
     
        <div  className="topcreators-img">
          <img src={bannerimage}  className="img-responsive" alt="Logo" />
          <div className="topcreators-rightcontent">
          <h3>lenin quies</h3>
            <p> 178 items</p>
          </div>
        </div>
   
      
        <div  className="topcreators-img">
          <img src={bannerimage}  className="img-responsive" alt="Logo" />
          <div className="topcreators-rightcontent">
          <h3>lenin quies</h3>
            <p> 178 items</p>
          </div>
        </div>
    
    
        <div  className="topcreators-img">
          <img src={bannerimage}  className="img-responsive" alt="Logo" />
          <div className="topcreators-rightcontent">
          <h3>lenin quies</h3>
            <p> 178 items</p>
          </div>
        </div>
    
      
        <div  className="topcreators-img">
          <img src={bannerimage}  className="img-responsive" alt="Logo" />
          <div className="topcreators-rightcontent">
          <h3>lenin quies</h3>
            <p> 178 items</p>
          </div>
          </div>
  
     
        <div  className="topcreators-img">
          <img src={bannerimage}  className="img-responsive" alt="Logo" />
          <div className="topcreators-rightcontent">
          <h3>lenin quies</h3>
            <p> 178 items</p>
          </div>
        </div>

     
        <div  className="topcreators-img">
          <img src={bannerimage}  className="img-responsive" alt="Logo" />
          <div className="topcreators-rightcontent">
          <h3>lenin quies</h3>
            <p> 178 items</p>
          </div>
        </div>

 
        <div  className="topcreators-img">
          <img src={bannerimage}  className="img-responsive" alt="Logo" />
          <div className="topcreators-rightcontent">
          <h3>lenin quies</h3>
            <p> 178 items</p>
          </div>
        </div>

        </div>
    </div>
    </div>
  )
}

export default Topcreators